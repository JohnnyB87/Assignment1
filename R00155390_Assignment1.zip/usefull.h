//
// Created by John on 06/03/2018.
//
#ifndef USEFUL_H_INCLUDED
#define USEFUL_H_INCLUDED

//--------------------------------------------------
// DATA TYPES DEFINITIONS
//--------------------------------------------------
enum Bool { False, True };
typedef enum Bool boolean;

char myGetChar();
#endif //